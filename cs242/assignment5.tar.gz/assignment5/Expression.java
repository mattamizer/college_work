/**@author Matthew Morrissey
 **@version 1.0
 **This interface allows for the implementation of an eval() method which takes a Machine instance.*/
public interface Expression{
    public void eval(Machine machine);
}