/**
 * @(#)Door.java
 *
 *
 * Matthew Morrissey 
 * version 1.00 2009/4/16
 * An extension of the Portal class that allows for the creation of Doors
 */


public class Door extends Portal
{
	public Door()
	{
		this.setName("door");
	}
}