/**
 * @(#)Room.java
 *
 *
 * Matthew Morrissey 
 * version 1.00 2009/4/16
 * Extends the Space class and allows for the creation of Rooms
 */


public class Room extends Space
{
	public Room()
    {
    	this.setName("room");
    }  
}