package com.PersonalData;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;

public class Personal_Data extends Activity {
	/** Called when the activity is first created. */
	EditText name;
	EditText email;
	Button save;
	RadioButton male;
	RadioButton female;
	RadioButton other;
	CheckBox spam;
	TextView saved;
	
	private ArrayList<String>data;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        name = (EditText)findViewById(R.id.EditTextName);
        email = (EditText)findViewById(R.id.EditTextEmail);
        Button save = (Button)findViewById(R.id.ButtonSave);
        male = (RadioButton)findViewById(R.id.RadioButtonMale);
        female = (RadioButton)findViewById(R.id.RadioButtonFemale);
        other = (RadioButton)findViewById(R.id.RadioButtonOther);
        spam = (CheckBox)findViewById(R.id.CheckBoxSpam);
        saved = (TextView)findViewById(R.id.TextViewSaved);
        //Log.i("Personal Data", "The value of PersonalDataAbout is " + (Object)findViewById(R.id.PersonalDataAbout));
        View contextView = findViewById(R.id.PersonalData);
        //contextView.setOnCreateContextMenuListener(this);
        //Log.i("Personal Data", "Made it " + (Object)contextView);
        registerForContextMenu(contextView);
        save.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		try {
            		data = new ArrayList<String>();
            		Log.i("Personal Data", "Save Initiated");
            		saved.setText("Saved");
            		Log.i("Personal Data", "Text Changed, moving to ArrayList");
            		data.add(0, (String)name.getText().toString());
            		data.add(1, (String)email.getText().toString());
            		if(spam.isChecked())
            			data.add(2, "checked");
            		else
            			data.add(2, "not_checked");
            		if(male.isChecked())
            			data.add(3, "male");
            		else if(female.isChecked())
            			data.add(3, "female");
            		else
            			data.add(3, "other");
            		
            			Log.i("Personal Data", "Initiating FileOutputString");
        				FileOutputStream fout = openFileOutput("data.txt", MODE_WORLD_READABLE);
        				OutputStreamWriter outWrite = new OutputStreamWriter(fout);
        				for(int i = 0; i < data.size(); i++){
        					outWrite.write(data.get(i) + "\n");
        				}
        				outWrite.flush();
        				outWrite.close();
        			} catch (FileNotFoundException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			} catch (IOException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			} catch (NullPointerException e){
        				e.printStackTrace();
        			}
        	}
        });
        name.setOnKeyListener(new OnKeyListener(){
        	public boolean onKey(View v, int keyCode, KeyEvent event){
        		saved.setText("Not Saved");
        		return false;
        	}
        });
        email.setOnKeyListener(new OnKeyListener(){
        	public boolean onKey(View v, int keyCode, KeyEvent event){
        		saved.setText("Not Saved");
        		return false;
        	}
        });
        male.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		saved.setText("Not Saved");
        	}
        });
        female.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		saved.setText("Not Saved");
        	}
        });
        other.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		saved.setText("Not Saved");
        	}
        });
        spam.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		saved.setText("Not Saved");
        	}
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
    	super.onCreateOptionsMenu(menu);
    	int loadItemID = 1;
    	int saveItemID = 2;
    	int optionsItemID = 3;
    	int order = Menu.NONE;
    	String loadName = "Load";
    	String saveName = "Save";
    	String optionsName = "Options";
    	@SuppressWarnings("unused")
		MenuItem load = menu.add(0, loadItemID, order, loadName);
    	@SuppressWarnings("unused")
		MenuItem save = menu.add(0, saveItemID, order, saveName);
    	@SuppressWarnings("unused")
		MenuItem options = menu.add(0, optionsItemID, order, optionsName);
    	return true;   	
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
    	super.onOptionsItemSelected(item);
    	switch(item.getItemId()){
    	case(1):
    		try {
				FileInputStream fin = openFileInput("data.txt");
				BufferedReader br = new BufferedReader(new InputStreamReader(fin));
				String s1, s2, s3, s4;
				s1 = br.readLine();
				s2 = br.readLine();
				s3 = br.readLine();
				s4 = br.readLine();
				
				name.setText(s1);
				email.setText(s2);
				if(s3.equals("checked"))
					spam.setChecked(true);
				else
					spam.setChecked(false);
				if(s4.equals("male"))
					male.setChecked(true);
				else if(s4.equals("female"))
					female.setChecked(true);
				else
					other.setChecked(true);
				br.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		return true;
    	case(2):
    		try {
    		data = new ArrayList<String>();
    		Log.i("Personal Data", "Save Initiated");
    		saved.setText("Saved");
    		Log.i("Personal Data", "Text Changed, moving to ArrayList");
    		data.add(0, (String)name.getText().toString());
    		data.add(1, (String)email.getText().toString());
    		if(spam.isChecked())
    			data.add(2, "checked");
    		else
    			data.add(2, "not_checked");
    		if(male.isChecked())
    			data.add(3, "male");
    		else if(female.isChecked())
    			data.add(3, "female");
    		else
    			data.add(3, "other");
    		
    			Log.i("Personal Data", "Initiating FileOutputString");
				FileOutputStream fout = openFileOutput("data.txt", MODE_WORLD_READABLE);
				OutputStreamWriter outWrite = new OutputStreamWriter(fout);
				for(int i = 0; i < data.size(); i++){
					outWrite.write(data.get(i) + "\n");
				}
				outWrite.flush();
				outWrite.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NullPointerException e){
				e.printStackTrace();
			}
			return true;
    	case(3):
    		Intent optionsIntent = new Intent(this, Options.class);
    		startActivity(optionsIntent);
    		return true;
    	}
    	return false;
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo info){
    	super.onCreateContextMenu(menu, v, info);
    	menu.setHeaderTitle("About");
    	menu.add(0, Menu.FIRST, Menu.NONE, "About");
    	//registerForContextMenu(findViewById(R.id.PersonalDataAbout));
    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
    	super.onContextItemSelected(item);
    	Intent aboutIntent = new Intent(this, About.class);
    	startActivity(aboutIntent);
    	return true;
    }
}