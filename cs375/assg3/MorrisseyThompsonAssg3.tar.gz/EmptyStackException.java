public class EmptyStackException extends Exception
{
    public EmptyStackException(String msg)
	{
		super(msg);
    }
}
